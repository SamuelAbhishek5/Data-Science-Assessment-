DAY 2 DATABRICKS SUBMISSION PACK - Abhishek M

This is an execution-ready starter pack, NOT proof of completed Databricks runs. No live Databricks workspace, original CSV files, or original notebook source was available here. Reference values are from the supplied solution guide, not newly observed results.

1. Obtain/import the instructor-provided D2_1, D2_2, D2_3 notebooks and three CSV files.
2. Confirm your actual assigned schema and whether the instructor uses a shared or participant Volume.
3. Execute each notebook in your non-production Databricks workspace.
4. Save real screenshots in evidence_screenshots folders; capture job run IDs, error logs, query plans and Delta versions.
5. Fill ACTUAL OBSERVED column in the Excel workbook; reference values are NOT submission evidence.
6. Include exported completed notebooks and submit the final ZIP after actual execution.

Important: Never run VACUUM. Only OPTIMIZE your dedicated training table if allowed. Do not make unauthorized GRANT changes.

Reference expected results: D2-1 input 1000/100/100; repaired initial 998; final 1048 and zero duplicate target keys. D2-2 intentional TRAINING_INJECTED_FAILURE then recovery 3 rows. D2-3 invalid table AnalysisException and corrected table 1048 rows. These values are NOT proof of your run.
